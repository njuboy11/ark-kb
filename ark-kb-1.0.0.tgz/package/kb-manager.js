/**
 * Ark KB — KBManager
 * Manages multiple knowledge bases as subfolders of knowledgePath.
 * Each KB = one LanceDB table (tableName = folder name).
 */
import * as fs from "node:fs";
import * as path from "node:path";
import { KnowledgeStore } from "./store.js";
import { Ingester, hashFile } from "./ingester.js";
import { Embedder } from "./embedder.js";
// Type guard helpers (inline to avoid circular dependency with config.ts)
function detectEmbeddingApi(endpoint) {
    const u = endpoint.toLowerCase();
    if (u.includes("siliconflow"))
        return "siliconflow";
    if (u.includes("dashscope") || u.includes("aliyun"))
        return "dashscope";
    if (u.includes("openai"))
        return "openai";
    return "custom";
}
/**
 * MultiKBManager — manages multiple LanceDB-backed knowledge bases.
 *
 * Directory structure:
 *   knowledgePath/
 *     default/         ← default KB (tableName = "default")
 *       file1.md
 *       file2.pdf
 *     project-a/      ← KB named "project-a"
 *       readme.md
 *     project-b/
 *       ...
 */
export class KBManager {
    knowledgePath;
    dbPath;
    vectorDim;
    embedderConfig;
    kbs = new Map();
    ingesters = new Map();
    _videoConfig;
    _imageConfig;
    _embeddingMethod;
    fullConfig;
    constructor(opts) {
        this.fullConfig = opts.fullConfig;
        this.knowledgePath = opts.knowledgePath;
        this.dbPath = opts.dbPath;
        this.vectorDim = opts.vectorDim;
        // Derive sub-configs from fullConfig if available, else fallback to explicit opts
        const ec = this.fullConfig?.embedding;
        this.embedderConfig = {
            api: ec?.api ?? opts.embedderConfig?.api ?? "",
            endpoint: ec?.endpoint ?? opts.embedderConfig?.endpoint ?? "",
            apiKey: ec?.apiKey ?? opts.embedderConfig?.apiKey ?? "",
            model: ec?.model ?? opts.embedderConfig?.model ?? "text-embedding-3-small",
            chunking: this.fullConfig?.chunking ?? opts.embedderConfig?.chunking ?? { maxTokens: 512, overlapTokens: 64, strategy: "paragraph" },
            pdfParser: this.fullConfig?.pdfParser ?? opts.embedderConfig?.pdfParser ?? { api: "none", endpoint: "", apiKey: "", model: "", params: {} },
        };
        this._videoConfig = {
            endpoint: this.fullConfig?.videoSummarizer?.endpoint ?? opts.videoConfig?.endpoint ?? "",
            apiKey: this.fullConfig?.videoSummarizer?.apiKey ?? opts.videoConfig?.apiKey ?? "",
            maxFrames: this.fullConfig?.videoSummarizer?.maxFrames ?? opts.videoConfig?.maxFrames ?? 100,
            timeoutMs: opts.videoConfig?.timeoutMs ?? 120_000,
        };
        this._imageConfig = {
            endpoint: this.fullConfig?.imageSummarizer?.endpoint ?? opts.imageConfig?.endpoint ?? "",
            apiKey: this.fullConfig?.imageSummarizer?.apiKey ?? opts.imageConfig?.apiKey ?? "",
            timeoutMs: opts.imageConfig?.timeoutMs ?? 60_000,
        };
        this._embeddingMethod = {
            image: this.fullConfig?.embedding?.method?.image ?? opts.embeddingMethod?.image ?? "text",
            video: this.fullConfig?.embedding?.method?.video ?? opts.embeddingMethod?.video ?? "text",
        };
    }
    // -------------------------------------------------------------------------
    // Init — scan knowledgePath, auto-migrate root files, init all KB stores
    // -------------------------------------------------------------------------
    /**
     * Initialize: scan subfolders, auto-migrate root-level files to `default`,
     * then init() all KnowledgeStore instances.
     */
    async init() {
        const kp = this.knowledgePath;
        fs.mkdirSync(kp, { recursive: true });
        // Auto-migrate: if root has files (not dirs), create `default` and move them
        await this._autoMigrate();
        // Scan subfolders
        const entries = fs.readdirSync(kp, { withFileTypes: true });
        const subDirs = entries.filter(e => e.isDirectory()).map(e => e.name);
        // Init each KB store in parallel
        await Promise.all(subDirs.map(name => this._initKB(name)));
    }
    /** Auto-migrate root-level files to a `default` KB. */
    async _autoMigrate() {
        const kp = this.knowledgePath;
        const entries = fs.readdirSync(kp, { withFileTypes: true });
        const rootFiles = entries.filter(e => e.isFile());
        if (rootFiles.length === 0)
            return;
        const defaultDir = path.join(kp, "default");
        fs.mkdirSync(defaultDir, { recursive: true });
        for (const entry of rootFiles) {
            const src = path.join(kp, entry.name);
            const dst = path.join(defaultDir, entry.name);
            fs.renameSync(src, dst);
            console.log(`[MultiKB] Migrated root file to default KB: ${entry.name}`);
        }
        console.log(`[MultiKB] Auto-migration complete: ${rootFiles.length} file(s) moved to "default"`);
    }
    /** Init a single KB store (creates folder if missing + inits KnowledgeStore). */
    async _initKB(name) {
        const kbDir = path.join(this.knowledgePath, name);
        fs.mkdirSync(kbDir, { recursive: true });
        const store = new KnowledgeStore({
            dbPath: this.dbPath,
            vectorDim: this.vectorDim,
            tableName: name,
        });
        await store.init();
        this.kbs.set(name, store);
        this.ingesters.set(name, this._makeIngester(store));
    }
    /** Build a minimal Ingester for the given store (PDF parsing disabled, no media summarizers). */
    _makeIngester(store) {
        const embedApi = this.embedderConfig.api ?? detectEmbeddingApi(this.embedderConfig.endpoint);
        const embedder = new Embedder({
            api: embedApi,
            endpoint: this.embedderConfig.endpoint,
            apiKey: this.embedderConfig.apiKey,
            model: this.embedderConfig.model,
            dimensions: this.vectorDim,
            batchSize: 16,
        });
        const pdfParser = this.embedderConfig.pdfParser
            ? { ...this.embedderConfig.pdfParser, model: this.embedderConfig.pdfParser.model ?? "", params: this.embedderConfig.pdfParser.params ?? {} }
            : { api: "none", endpoint: "", apiKey: "", model: "", params: {} };
        return new Ingester(store, embedder, { chunking: this.embedderConfig.chunking, pdfParser }, this.knowledgePath, { endpoint: this._videoConfig.endpoint, apiKey: this._videoConfig.apiKey, maxFrames: this._videoConfig.maxFrames, timeoutMs: this._videoConfig.timeoutMs }, { endpoint: this._imageConfig.endpoint, apiKey: this._imageConfig.apiKey, timeoutMs: this._imageConfig.timeoutMs }, { imageMethod: this._embeddingMethod.image, videoMethod: this._embeddingMethod.video });
    }
    // -------------------------------------------------------------------------
    // KB CRUD
    // -------------------------------------------------------------------------
    /**
     * Create a new knowledge base (subfolder + LanceDB table).
     */
    async createKB(name) {
        const sanitized = name.trim();
        if (!sanitized)
            throw new Error("[MultiKB] KB name cannot be empty");
        if (this.kbs.has(sanitized)) {
            throw new Error(`[MultiKB] KB "${sanitized}" already exists`);
        }
        await this._initKB(sanitized);
        console.log(`[MultiKB] Created KB: "${sanitized}"`);
    }
    /**
     * Delete a knowledge base.
     * @param name KB name
     * @param confirm Must be true to execute deletion
     * @returns confirmation prompt if confirm=false, otherwise deletes and returns result
     */
    async deleteKB(name, confirm) {
        if (!this.kbs.has(name)) {
            throw new Error(`[MultiKB] KB "${name}" does not exist`);
        }
        if (!confirm) {
            return {
                message: `⚠️ Are you sure you want to delete KB "${name}"? This will remove all chunks and delete the folder. Reply with confirm=true to proceed.`,
                requiresConfirm: true,
            };
        }
        const store = this.kbs.get(name);
        await store.drop();
        this.kbs.delete(name);
        this.ingesters.delete(name);
        // Remove the folder
        const kbDir = path.join(this.knowledgePath, name);
        fs.rmSync(kbDir, { recursive: true, force: true });
        console.log(`[MultiKB] Deleted KB: "${name}"`);
        return { deleted: true, kbName: name };
    }
    /**
     * List all knowledge bases with file count and chunk count.
     */
    async listKBs() {
        const results = [];
        for (const [name, store] of this.kbs.entries()) {
            try {
                const info = await store.tableInfo();
                results.push({
                    name,
                    path: path.join(this.knowledgePath, name),
                    fileCount: info.files.length,
                    chunkCount: info.chunks,
                });
            }
            catch {
                results.push({ name, path: path.join(this.knowledgePath, name), fileCount: 0, chunkCount: 0 });
            }
        }
        return results;
    }
    /**
     * Get a KnowledgeStore instance by KB name.
     */
    getKB(name) {
        return this.kbs.get(name);
    }
    /**
     * Get the name of the default KB ("default" if it exists, otherwise first KB).
     */
    getDefaultKBName() {
        if (this.kbs.has("default"))
            return "default";
        const first = this.kbs.keys().next().value;
        return first ?? "";
    }
    /**
     * Get all KB names.
     */
    getAllKBNames() {
        return [...this.kbs.keys()];
    }
    /**
     * Get an Ingester instance by KB name.
     */
    getIngester(name) {
        return this.ingesters.get(name);
    }
    /**
     * Compact a single KB: merge fragments, prune old versions, remap index.
     */
    async compact(kbName, options) {
        const store = this.kbs.get(kbName);
        if (!store) {
            console.warn(`[KBManager] compact: KB "${kbName}" not found`);
            return null;
        }
        const stats = await store.compact({
            cleanupDays: options.cleanupDays,
            aggressive: options.aggressive,
            dryRun: options.dryRun,
        });
        return stats;
    }
    /**
     * Compact all knowledge bases.
     */
    async compactAll(options) {
        const results = [];
        for (const name of this.kbs.keys()) {
            const stats = await this.compact(name, options);
            if (stats)
                results.push(stats);
        }
        return {
            results,
            totalBytesFreed: results.reduce((s, r) => s +
                (r.compaction?.bytesFreed ?? 0) +
                (r.prune?.bytesRemoved ?? 0), 0),
            totalFragmentsMerged: results.reduce((s, r) => s + (r.compaction?.fragmentsRemoved ?? 0), 0),
            totalDurationMs: results.reduce((s, r) => s + r.durationMs, 0),
        };
    }
    /**
     * Heal a single KB: scan its directory and re-ingest changed/new files.
     */
    async healKB(kbName) {
        const ingester = this.ingesters.get(kbName);
        if (!ingester) {
            console.warn(`[KBManager] heal: KB "${kbName}" not found`);
            return { healed: 0, skipped: 0 };
        }
        const kbDir = path.join(this.knowledgePath, kbName);
        if (!fs.existsSync(kbDir)) {
            console.warn(`[KBManager] heal: directory not found: ${kbDir}`);
            return { healed: 0, skipped: 0 };
        }
        return ingester.heal(kbDir);
    }
    /** Heal all KBs. */
    async healAll() {
        let totalHealed = 0;
        let totalSkipped = 0;
        const byKB = {};
        for (const name of this.kbs.keys()) {
            const r = await this.healKB(name);
            byKB[name] = r;
            totalHealed += r.healed;
            totalSkipped += r.skipped;
        }
        return { healed: totalHealed, skipped: totalSkipped, byKB };
    }
    /**
     * Rebuild a KB: drop the LanceDB table, recreate it, re-ingest all files.
     * Requires --confirm because it destroys existing data.
     */
    async rebuildKB(kbName) {
        const store = this.kbs.get(kbName);
        const ingester = this.ingesters.get(kbName);
        if (!store || !ingester) {
            throw new Error(`KB "${kbName}" not found`);
        }
        // 1. Drop the LanceDB table
        await store.drop();
        // 2. Reinitialize the store (creates new table + FTS index)
        await store.init();
        // 3. Re-heal the directory
        const kbDir = path.join(this.knowledgePath, kbName);
        const result = await ingester.heal(kbDir);
        return { healed: result.healed, skipped: result.skipped, kbName };
    }
    /** Rebuild all KBs. */
    async rebuildAll() {
        const results = [];
        for (const name of this.kbs.keys()) {
            const r = await this.rebuildKB(name);
            results.push(r);
        }
        return results;
    }
    /**
     * Re-ingest all files in a directory (heal/re-index).
     * Returns aggregate healed + skipped counts across all KBs.
     * @deprecated Use healKB() or healAll() instead.
     */
    async heal(knowledgePath) {
        let totalHealed = 0;
        let totalSkipped = 0;
        for (const [name, ingester] of this.ingesters.entries()) {
            const kbDir = path.join(knowledgePath, name);
            if (!fs.existsSync(kbDir))
                continue;
            try {
                const result = await ingester.heal(kbDir);
                totalHealed += result.healed;
                totalSkipped += result.skipped;
            }
            catch (err) {
                console.warn(`[KBManager] heal skip for KB "${name}": ${err.message}`);
            }
        }
        return { healed: totalHealed, skipped: totalSkipped };
    }
    // -------------------------------------------------------------------------
    // Search across all KBs
    // -------------------------------------------------------------------------
    /**
     * Search all knowledge bases and merge/rank results.
     * @param query Query string
     * @param searchFn Function that takes (KnowledgeStore, query, topK) and returns search results
     * @param topK Top results per KB (default 5)
     */
    async searchAll(query, searchFn, topK = 5) {
        const tasks = [...this.kbs.entries()].map(async ([name, store]) => {
            try {
                const hits = await searchFn(store, query, topK);
                return hits.map(h => ({ ...h, kbName: name }));
            }
            catch (err) {
                console.warn(`[MultiKB] Search failed for KB "${name}": ${err.message}`);
                return [];
            }
        });
        const arrays = await Promise.all(tasks);
        const merged = arrays.flat();
        // Sort by score descending
        merged.sort((a, b) => b.score - a.score);
        return merged;
    }
    // -------------------------------------------------------------------------
    // File ingestion
    // -------------------------------------------------------------------------
    /**
     * Ingest a file into the appropriate KB based on its path.
     * Determines KB by the folder the file is in.
     *
     * Three-layer deduplication:
     * Layer 1 — same name + same hash: skip (filesystem)
     * Layer 2 — same name + different hash: rename with _1, _2 suffix (filesystem)
     * Layer 3 — different name + same hash: skip (DB hash check in ingester)
     */
    /**
     * Ingest a file by path. Resolves the correct KB automatically unless
     * kbName is provided (e.g. from EmailIngester which already knows the target).
     */
    async ingestByPath(filePath, kbName) {
        const resolved = path.resolve(filePath);
        const targetKB = kbName ?? this._resolveKBForPath(resolved);
        const kbPath = path.join(this.knowledgePath, targetKB);
        // Layers 1 & 2: filesystem deduplication
        const destName = path.basename(resolved);
        const destPath = path.join(kbPath, destName);
        if (fs.existsSync(destPath)) {
            // If source and dest are the same file (e.g. emailIngester already copied),
            // skip the self-comparison and go straight to ingest.
            const sameFile = path.resolve(resolved) === path.resolve(destPath);
            if (!sameFile) {
                // Compute both hashes to decide: skip or rename
                const [newHash, oldHash] = await Promise.all([
                    hashFile(resolved),
                    hashFile(destPath),
                ]);
                if (newHash === oldHash) {
                    // Layer 1: same name + same hash → skip
                    console.log(`[MultiKB] Skipping duplicate (same name + hash): ${destName}`);
                    return { entries: 0, source: destName, skipped: true, kbName: targetKB };
                }
                // Layer 2: same name + different hash → rename
                const uniqueName = this._getUniqueFilename(destName, kbPath);
                const uniquePath = path.join(kbPath, uniqueName);
                fs.copyFileSync(resolved, uniquePath);
                console.log(`[MultiKB] Renamed to avoid conflict: ${destName} → ${uniqueName}`);
                const result = await this.ingesters.get(targetKB).ingestFile(uniquePath);
                return { ...result, kbName: targetKB };
            }
            // sameFile: already in KB dir, no copy needed — fall through to ingest
        }
        else {
            // No conflict — copy file to KB folder and ingest
            fs.copyFileSync(resolved, destPath);
        }
        const ingester = this.ingesters.get(targetKB);
        if (!ingester) {
            throw new Error(`[MultiKB] No ingester for KB "${targetKB}" — is the KB initialized?`);
        }
        const result = await ingester.ingestFile(destPath);
        return { ...result, kbName: targetKB };
    }
    /**
     * Generate a unique filename by appending _1, _2, etc. if conflicts exist.
     */
    _getUniqueFilename(baseName, kbPath) {
        const ext = path.extname(baseName);
        const stem = path.basename(baseName, ext);
        let i = 1;
        while (fs.existsSync(path.join(kbPath, `${stem}_${i}${ext}`))) {
            i++;
        }
        return `${stem}_${i}${ext}`;
    }
    /**
     * Determine which KB a file belongs to based on its path.
     * Falls back to "default" if the immediate parent folder is not a known KB.
     */
    _resolveKBForPath(filePath) {
        const kp = path.resolve(this.knowledgePath);
        const abs = path.resolve(filePath);
        // Walk up from the file's parent until we hit or exceed knowledgePath
        let current = path.dirname(abs);
        while (current !== kp && current !== path.dirname(kp)) {
            const parent = path.dirname(current);
            const folderName = path.basename(current);
            if (this.kbs.has(folderName)) {
                // Check the parent actually matches knowledgePath/<folderName>
                const expectedParent = path.join(kp, folderName);
                if (path.resolve(parent) === kp && path.resolve(current) === expectedParent) {
                    return folderName;
                }
            }
            current = parent;
        }
        // If file is directly under knowledgePath root, try to match top folder name
        const rel = path.relative(kp, abs);
        const topFolder = rel.split(path.sep)[0];
        if (topFolder && this.kbs.has(topFolder)) {
            return topFolder;
        }
        // Fallback to "default" if it exists, otherwise first KB
        if (this.kbs.has("default"))
            return "default";
        const first = this.kbs.keys().next().value;
        if (!first)
            throw new Error("[MultiKB] No KBs initialized — call init() first");
        return first;
    }
    // -------------------------------------------------------------------------
    // Remove from all KBs
    // -------------------------------------------------------------------------
    _removeLock = Promise.resolve();
    /**
     * Remove a file (by source path) from all knowledge bases.
     */
    async removeFromAll(sourcePath) {
        // Serialize to prevent concurrent removal races
        const prev = this._removeLock;
        let resolve;
        this._removeLock = new Promise(r => { resolve = r; });
        await prev;
        try {
            const results = [];
            for (const [name, store] of this.kbs.entries()) {
                try {
                    const deleted = await store.deleteBySource(sourcePath);
                    results.push({ kbName: name, deleted });
                }
                catch (err) {
                    console.warn(`[MultiKB] removeFromAll failed for KB "${name}": ${err.message}`);
                    results.push({ kbName: name, deleted: 0 });
                }
            }
            return results;
        }
        finally {
            resolve();
        }
    }
    // -------------------------------------------------------------------------
    // Shutdown
    // -------------------------------------------------------------------------
    async close() {
        await Promise.all([...this.kbs.values()].map(s => s.close()));
        this.kbs.clear();
        this.ingesters.clear();
    }
}
//# sourceMappingURL=kb-manager.js.map